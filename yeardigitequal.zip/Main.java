import java.util.*;
public class Main{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int y=sc.nextInt();
int first=y/100;
int last=y%100;
if(first==last) System.out.println("Equal");
else System.out.println("Not Equal");
}
}
