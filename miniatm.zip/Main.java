import java.util.*;
public class Main{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int balance=10000;
int choice=sc.nextInt();
switch(choice){
case 1:System.out.println(balance);break;
case 2:int dep=sc.nextInt();balance+=dep;System.out.println(balance);break;
case 3:int wit=sc.nextInt();if(wit<=balance){balance-=wit;System.out.println(balance);}else System.out.println("Insufficient");break;
case 4:System.out.println("Exit");break;
default:System.out.println("Invalid");
}
}
}
