import java.util.*;
public class Main{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int d=sc.nextInt();
switch(d){
case 1:
case 2:
case 3:
case 4:
case 5:System.out.println("Weekday");break;
case 6:
case 7:System.out.println("Weekend");break;
default:System.out.println("Invalid");
}
}
}
