import java.util.*;
public class Main{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int bill=sc.nextInt();
int discount;
if(bill>=5000) discount=20;
else if(bill>=3000) discount=15;
else if(bill>=1000) discount=10;
else discount=0;
int discountAmount=bill*discount/100;
int finalAmount=bill-discountAmount;
System.out.println(discountAmount);
System.out.println(finalAmount);
}
}
